def fallosMuneco(x):
    if x == 8:
        print(" +---+")
        print("     |") 
        print("     |") 
        print("     |")    
        print("     |")   
        print("     |")
        print("     |")   
        print("==========")#listo
        return True

    elif x == 7:
        print(" +---+")
        print(" |   |") 
        print("     |") 
        print("     |")    
        print("     |")   
        print("     |")
        print("     |")   
        print("==========")#listo
        return True
        
    elif x == 6:
        print(" +---+")
        print(" |   |") 
        print(" |   |") 
        print("     |")    
        print("     |")   
        print("     |")
        print("     |")   
        print("==========")#listo
        return True
        
    elif x == 5:
        print(" +---+")
        print(" |   |") 
        print(" |   |") 
        print(" o   |")    
        print("     |")   
        print("     |")
        print("     |")   
        print("==========")#listo
        return True
        
    elif x == 4:
        print(" +---+")
        print(" |   |") 
        print(" |   |") 
        print(" o   |")    
        print(" |   |")   
        print("     |")
        print("     |")   
        print("==========")#listo
        return True
        
    elif x == 3:
        print(" +---+")
        print(" |   |") 
        print(" |   |") 
        print(" o   |")    
        print("/|   |")   
        print("     |")
        print("     |")   
        print("==========")
        return True
        
    elif x == 2:
        print(" +---+")
        print(" |   |") 
        print(" |   |") 
        print(" o   |")    
        print("/|\  |")   
        print("     |")
        print("     |")   
        print("==========")#
        return True
        
    elif x == 1:
        print(" +---+")
        print(" |   |") 
        print(" |   |") 
        print(" o   |")    
        print("/|\  |")   
        print("/    |")
        print("     |")   
        print("==========")
        return True
        
    elif x == 0:
         print(" +---+")
         print(" |   |") 
         print(" |   |") 
         print(" o   |")    
         print("/|\  |")   
         print("/ \  |")
         print("     |")   
         print("==========")
         return True
         
         
         
         
         
         
         
         
         
         
         
         
         
"""
 +---+
 |   | 
     | 
     |    
     |    
     |
     |   
==========



 +---+
 |   | 
 |   | 
     |    
     |    
     |
     |   
==========



 +---+
 |   | 
 |   | 
 O   |    
     |    
     |
     |   
==========



 +---+
 |   | 
 |   | 
 O   |    
 |   |    
     |
     |   
==========

 +---+
 |   | 
 |   | 
 O   |    
/|   |    
     |
     |   
==========



 +---+
 |   | 
 |   | 
 O   |    
/|\  |    
     |
     |   
==========



 +---+
 |   | 
 |   | 
 O   |    
/|\  |    
/    |
     |   
==========



 +---+
 |   | 
 |   | 
 O   |    
/|\  |    
/ \  |
     |   
==========
"""
