print("Ingresa el kilometraje del carro, por favor:")
distanceCar = int(input())
numberChangeOil = distanceCar // 5678
print("Las veces que se le tuvo que cambiar al carro el aceite son:", numberChangeOil)
