# Algoritmo parOinpar
print("Ingrese el número a verificar:")
numberToCheck = int(input())

if numberToCheck % 2 == 0:
    print("El número es par")
else:
    print("El número es impar")
